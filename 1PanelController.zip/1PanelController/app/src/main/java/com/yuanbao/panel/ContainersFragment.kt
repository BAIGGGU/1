package com.yuanbao.panel

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ContainersFragment : Fragment(R.layout.fragment_list), Refreshable {

    private lateinit var client: PanelClient
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var recycler: RecyclerView
    private lateinit var empty: TextView
    private val adapter = ContainerAdapter { item, op -> confirmOperate(item, op) }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        client = (requireActivity() as MainActivity).client
        swipe = view.findViewById(R.id.swipe)
        recycler = view.findViewById(R.id.recycler)
        empty = view.findViewById(R.id.tvEmpty)
        empty.text = "暂无容器"

        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter
        swipe.setOnRefreshListener { load() }
        load()
    }

    override fun refresh() {
        if (::swipe.isInitialized) {
            swipe.isRefreshing = true
            load()
        }
    }

    private fun load() {
        if (!isAdded) return
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val list = withContext(Dispatchers.IO) { client.containers() }
                adapter.submit(list)
                empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                if (isAdded) {
                    Snackbar.make(requireView(), "拉取失败：${e.message}", Snackbar.LENGTH_LONG).show()
                }
            }
            if (::swipe.isInitialized) swipe.isRefreshing = false
        }
    }

    private fun confirmOperate(item: ContainerInfo, op: String) {
        val name = item.name ?: return
        val label = when (op) {
            ContainerOp.START -> "启动"
            ContainerOp.STOP -> "停止"
            ContainerOp.RESTART -> "重启"
            ContainerOp.REMOVE -> "删除"
            else -> op
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("确认${label}")
            .setMessage("容器：$name")
            .setNegativeButton("取消", null)
            .setPositiveButton(label) { _, _ -> operate(name, op) }
            .show()
    }

    private fun operate(name: String, op: String) {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) { client.containerOperate(listOf(name), op) }
                if (isAdded) Snackbar.make(requireView(), "操作已提交：$name", Snackbar.LENGTH_SHORT).show()
                load()
            } catch (e: Exception) {
                if (isAdded) {
                    Snackbar.make(requireView(), "操作失败：${e.message}", Snackbar.LENGTH_LONG).show()
                }
            }
        }
    }
}

private class ContainerAdapter(
    private val onOp: (ContainerInfo, String) -> Unit
) : RecyclerView.Adapter<ContainerAdapter.Holder>() {

    private val data = mutableListOf<ContainerInfo>()

    fun submit(list: List<ContainerInfo>) {
        data.clear()
        data.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_container, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(h: Holder, pos: Int) {
        val item = data[pos]
        h.name.text = item.name ?: "-"
        h.image.text = item.image ?: "-"
        val state = item.state ?: "-"
        h.state.text = state
        val color = when (state.lowercase()) {
            "running" -> android.R.color.holo_green_dark
            "exited", "stopped" -> android.R.color.holo_red_dark
            "paused" -> android.R.color.holo_orange_dark
            else -> android.R.color.darker_gray
        }
        h.state.setTextColor(ContextCompat.getColor(h.itemView.context, color))
        h.status.text = item.status ?: ""
        h.btnStart.setOnClickListener { onOp(item, ContainerOp.START) }
        h.btnStop.setOnClickListener { onOp(item, ContainerOp.STOP) }
        h.btnRestart.setOnClickListener { onOp(item, ContainerOp.RESTART) }
        h.btnRemove.setOnClickListener { onOp(item, ContainerOp.REMOVE) }
    }

    override fun getItemCount(): Int = data.size

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val name: TextView = v.findViewById(R.id.tvName)
        val image: TextView = v.findViewById(R.id.tvImage)
        val state: TextView = v.findViewById(R.id.tvState)
        val status: TextView = v.findViewById(R.id.tvStatus)
        val btnStart: View = v.findViewById(R.id.btnStart)
        val btnStop: View = v.findViewById(R.id.btnStop)
        val btnRestart: View = v.findViewById(R.id.btnRestart)
        val btnRemove: View = v.findViewById(R.id.btnRemove)
    }
}
