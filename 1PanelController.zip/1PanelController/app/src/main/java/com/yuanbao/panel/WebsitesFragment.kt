package com.yuanbao.panel

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class WebsitesFragment : Fragment(R.layout.fragment_list), Refreshable {

    private lateinit var client: PanelClient
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var recycler: RecyclerView
    private lateinit var empty: TextView
    private val adapter = WebsiteAdapter { item -> openSite(item) }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        client = (requireActivity() as MainActivity).client
        swipe = view.findViewById(R.id.swipe)
        recycler = view.findViewById(R.id.recycler)
        empty = view.findViewById(R.id.tvEmpty)
        empty.text = "暂无网站"

        recycler.layoutManager = LinearLayoutManager(requireContext())
        recycler.adapter = adapter
        swipe.setOnRefreshListener { load() }
        load()
    }

    override fun refresh() {
        if (::swipe.isInitialized) {
            swipe.isRefreshing = true
            load()
        }
    }

    private fun load() {
        if (!isAdded) return
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val list = withContext(Dispatchers.IO) { client.websites() }
                adapter.submit(list)
                empty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            } catch (e: Exception) {
                if (isAdded) {
                    Snackbar.make(requireView(), "拉取失败：${e.message}", Snackbar.LENGTH_LONG).show()
                }
            }
            if (::swipe.isInitialized) swipe.isRefreshing = false
        }
    }

    private fun openSite(item: WebsiteInfo) {
        val domain = item.primaryDomain
        if (domain.isNullOrBlank()) return
        val proto = if ((item.protocol ?: "").contains("https", true)) "https" else "http"
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("$proto://$domain")))
        } catch (e: Exception) {
            if (isAdded) Snackbar.make(requireView(), "无法打开：$domain", Snackbar.LENGTH_SHORT).show()
        }
    }
}

private class WebsiteAdapter(
    private val onClick: (WebsiteInfo) -> Unit
) : RecyclerView.Adapter<WebsiteAdapter.Holder>() {

    private val data = mutableListOf<WebsiteInfo>()

    fun submit(list: List<WebsiteInfo>) {
        data.clear()
        data.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_website, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(h: Holder, pos: Int) {
        val item = data[pos]
        h.domain.text = item.primaryDomain ?: "-"
        h.meta.text = listOfNotNull(item.type, item.alias, item.remark)
            .filter { it.isNotBlank() }
            .joinToString(" · ")
            .ifBlank { item.status ?: "" }
        h.status.text = item.status ?: "-"
        h.itemView.setOnClickListener { onClick(item) }
    }

    override fun getItemCount(): Int = data.size

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val domain: TextView = v.findViewById(R.id.tvDomain)
        val meta: TextView = v.findViewById(R.id.tvMeta)
        val status: TextView = v.findViewById(R.id.tvStatus)
    }
}
