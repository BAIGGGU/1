package com.yuanbao.panel

import android.content.Context
import com.google.gson.Gson

object AuthMode {
    const val API_KEY = "apikey"
    const val JWT = "jwt"
}

object SignMode {
    const val HMAC = "hmac"
    const val MD5 = "md5"
}

object ApiVer {
    const val V2 = "v2"
    const val V1 = "v1"
}

object ContainerOp {
    const val START = "start"
    const val STOP = "stop"
    const val RESTART = "restart"
    const val KILL = "kill"
    const val PAUSE = "pause"
    const val UNPAUSE = "unpause"
    const val REMOVE = "remove"
}

data class PanelConfig(
    var baseUrl: String = "",
    var apiVersion: String = ApiVer.V2,
    var authMode: String = AuthMode.API_KEY,
    var signMode: String = SignMode.HMAC,
    var apiKey: String = "",
    var username: String = "",
    var password: String = "",
    var entranceCode: String = "",
    var trustAll: Boolean = true,
    var autoRefresh: Boolean = true,
    var jwtToken: String = ""
)

object Prefs {
    private const val FILE = "panel_prefs"
    private const val KEY = "config"
    private val gson = Gson()

    fun load(ctx: Context): PanelConfig {
        val raw = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString(KEY, "")
        if (raw.isNullOrBlank()) return PanelConfig()
        return try {
            gson.fromJson(raw, PanelConfig::class.java) ?: PanelConfig()
        } catch (e: Exception) {
            PanelConfig()
        }
    }

    fun save(ctx: Context, cfg: PanelConfig) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY, gson.toJson(cfg))
            .apply()
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
