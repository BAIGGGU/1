package com.yuanbao.panel

import android.util.Base64
import com.google.gson.Gson
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonParser
import okhttp3.Headers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class PanelException(val code: Int, msg: String) : Exception(msg)

class PanelClient(private var cfg: PanelConfig) {

    private val gson = Gson()
    private val jsonType = "application/json; charset=utf-8".toMediaType()
    private var http: OkHttpClient = buildClient()

    fun config(): PanelConfig = cfg

    fun updateConfig(newCfg: PanelConfig) {
        cfg = newCfg
        http = buildClient()
    }

    private fun buildClient(): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .callTimeout(45, TimeUnit.SECONDS)
        if (cfg.trustAll) {
            val trustAll = object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            }
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(trustAll), SecureRandom())
            builder.sslSocketFactory(ctx.socketFactory, trustAll)
            builder.hostnameVerifier { _, _ -> true }
        }
        return builder.build()
    }

    fun baseUrl(): String = cfg.baseUrl.trim().trimEnd('/') + "/api/" + cfg.apiVersion

    fun swaggerUrl(): String = cfg.baseUrl.trim().trimEnd('/') + "/1panel/swagger/index.html"

    private fun authHeaders(): Headers {
        val b = Headers.Builder()
        b.add("Content-Type", "application/json")
        b.add("Accept", "application/json")
        when (cfg.authMode) {
            AuthMode.JWT -> {
                if (cfg.jwtToken.isNotBlank()) b.add("PanelAuthorization", cfg.jwtToken)
            }
            else -> {
                val ts = (System.currentTimeMillis() / 1000).toString()
                b.add("1Panel-Timestamp", ts)
                b.add("1Panel-Token", sign(ts))
            }
        }
        if (cfg.entranceCode.isNotBlank()) {
            b.add(
                "EntranceCode",
                Base64.encodeToString(cfg.entranceCode.trim().toByteArray(), Base64.NO_WRAP)
            )
        }
        return b.build()
    }

    private fun sign(ts: String): String = when (cfg.signMode) {
        SignMode.MD5 -> md5Hex("1panel" + cfg.apiKey + ts)
        else -> hmacSha256Hex(cfg.apiKey, "1panel:$ts")
    }

    private fun md5Hex(src: String): String {
        val bytes = MessageDigest.getInstance("MD5").digest(src.toByteArray(Charsets.UTF_8))
        return hex(bytes)
    }

    private fun hmacSha256Hex(key: String, msg: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return hex(mac.doFinal(msg.toByteArray(Charsets.UTF_8)))
    }

    private fun hex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        bytes.forEach { b ->
            val v = b.toInt() and 0xFF
            if (v < 16) sb.append('0')
            sb.append(v.toString(16))
        }
        return sb.toString()
    }

    fun get(path: String): JsonElement {
        val req = Request.Builder()
            .url(baseUrl() + "/" + path.trimStart('/'))
            .headers(authHeaders())
            .get()
            .build()
        return execute(req)
    }

    fun post(path: String, payload: Any? = null): JsonElement {
        val body = (if (payload == null) "{}" else gson.toJson(payload)).toRequestBody(jsonType)
        val req = Request.Builder()
            .url(baseUrl() + "/" + path.trimStart('/'))
            .headers(authHeaders())
            .post(body)
            .build()
        return execute(req)
    }

    private fun execute(req: Request): JsonElement {
        http.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw PanelException(resp.code, "HTTP ${resp.code}：${text.take(160)}")
            }
            val obj = JsonParser.parseString(text).asJsonObject
            val code = if (obj.has("code")) obj.get("code").asInt else 200
            if (code != 200) {
                val msg = if (obj.has("message")) obj.get("message").asString else "code=$code"
                throw PanelException(code, msg)
            }
            val data = obj.get("data")
            return if (data == null || data.isJsonNull) JsonNull.INSTANCE else data
        }
    }

    // ---------- 业务接口 ----------

    /** 账号密码登录，返回 JWT，并写入配置 */
    fun login(): String {
        val payload = mapOf(
            "name" to cfg.username,
            "password" to cfg.password,
            "authMethod" to "jwt",
            "language" to "zh",
            "ignoreCaptcha" to true,
            "captcha" to "",
            "captchaID" to ""
        )
        val path = if (cfg.apiVersion == ApiVer.V1) "auth/login" else "core/auth/login"
        val data = post(path, payload)
        val token = if (data.isJsonPrimitive) {
            data.asString
        } else {
            data.asJsonObject.get("token")?.asString.orEmpty()
        }
        if (token.isBlank()) throw PanelException(-1, "登录成功但未获取到 token")
        cfg.jwtToken = token
        return token
    }

    fun dashboardBase(): DashboardBase = gson.fromJson(get("dashboard/base/all/all"), DashboardBase::class.java)

    fun dashboardCurrent(): CurrentInfo = gson.fromJson(get("dashboard/current/all/all"), CurrentInfo::class.java)

    fun containers(): List<ContainerInfo> {
        val data = post("containers/search", mapOf("page" to 1, "pageSize" to 300))
        return items(data, ContainerInfo::class.java)
    }

    fun containerOperate(names: List<String>, operation: String) {
        post("containers/operate", mapOf("names" to names, "operation" to operation))
    }

    fun websites(): List<WebsiteInfo> {
        val data = try {
            post("websites/search", mapOf("page" to 1, "pageSize" to 300))
        } catch (e: PanelException) {
            if (e.code == 404 || e.code == 405) get("websites/search?page=1&pageSize=300") else throw e
        }
        return items(data, WebsiteInfo::class.java)
    }

    /** 连通性测试：先取一次概览基础信息 */
    fun testConnection(): String {
        val base = dashboardBase()
        return listOfNotNull(base.hostname, base.prettyDistro ?: base.platform, base.ipV4Addr)
            .filter { it.isNotBlank() }
            .joinToString(" / ")
            .ifBlank { "连接成功" }
    }

    private fun <T> items(data: JsonElement, clazz: Class<T>): List<T> {
        val arr = when {
            data.isJsonArray -> data.asJsonArray
            data.isJsonObject && data.asJsonObject.has("items") -> {
                val it = data.asJsonObject.get("items")
                if (it.isJsonArray) it.asJsonArray else return emptyList()
            }
            else -> return emptyList()
        }
        val out = ArrayList<T>(arr.size())
        arr.forEach { e ->
            if (e.isJsonObject) out.add(gson.fromJson(e.asJsonObject, clazz))
        }
        return out
    }
}
