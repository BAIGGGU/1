package com.yuanbao.panel

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class OverviewFragment : Fragment(R.layout.fragment_overview), Refreshable {

    private lateinit var client: PanelClient
    private lateinit var swipe: SwipeRefreshLayout
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            load(silent = true)
            handler.postDelayed(this, REFRESH_MS)
        }
    }

    private var lastSent: Long = 0
    private var lastRecv: Long = 0
    private var lastTs: Long = 0

    @Volatile
    private var baseCache: DashboardBase? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        client = (requireActivity() as MainActivity).client
        swipe = view.findViewById(R.id.swipe)
        swipe.setOnRefreshListener { load(forceBase = true) }
        load(forceBase = true)
    }

    override fun onResume() {
        super.onResume()
        if (::client.isInitialized && client.config().autoRefresh) startTicker()
    }

    override fun onPause() {
        stopTicker()
        super.onPause()
    }

    private fun startTicker() {
        stopTicker()
        handler.postDelayed(ticker, REFRESH_MS)
    }

    private fun stopTicker() {
        handler.removeCallbacks(ticker)
    }

    override fun refresh() {
        if (::swipe.isInitialized) {
            swipe.isRefreshing = true
            load(forceBase = true)
        }
    }

    /** @param forceBase 是否重新拉取基础信息（下拉刷新时才需要，轮询只取实时数据） */
    private fun load(forceBase: Boolean = false, silent: Boolean = false) {
        if (!isAdded) return
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val data = withContext(Dispatchers.IO) {
                    val base = if (forceBase || baseCache == null) client.dashboardBase() else baseCache!!
                    Pair(base, client.dashboardCurrent())
                }
                baseCache = data.first
                render(data.first, data.second)
            } catch (e: Exception) {
                if (isAdded && !silent) {
                    Snackbar.make(requireView(), "拉取失败：${e.message}", Snackbar.LENGTH_LONG).show()
                }
            }
            if (::swipe.isInitialized) swipe.isRefreshing = false
        }
    }

    private fun render(base: DashboardBase, cur: CurrentInfo) {
        val v = view ?: return
        v.findViewById<TextView>(R.id.tvHost).text = base.hostname ?: "-"
        v.findViewById<TextView>(R.id.tvOs).text = listOfNotNull(
            base.prettyDistro ?: base.platform,
            base.platformVersion,
            base.kernelArch
        ).joinToString(" ")
        v.findViewById<TextView>(R.id.tvKernel).text = base.kernelVersion ?: "-"
        v.findViewById<TextView>(R.id.tvCpu).text =
            "${base.cpuModelName ?: "-"}（${Fmt.num(base.cpuCores)} 核 / ${Fmt.num(base.cpuLogicalCores)} 线程）"
        v.findViewById<TextView>(R.id.tvIp).text = base.ipV4Addr ?: "-"
        v.findViewById<TextView>(R.id.tvUptime).text = cur.timeSinceUptime ?: Fmt.num(cur.uptime)

        v.findViewById<ProgressBar>(R.id.pbCpu).progress = (cur.cpuUsedPercent ?: 0.0).toInt().coerceIn(0, 100)
        v.findViewById<TextView>(R.id.tvCpuVal).text = Fmt.pct(cur.cpuUsedPercent)

        v.findViewById<ProgressBar>(R.id.pbMem).progress = (cur.memoryUsedPercent ?: 0.0).toInt().coerceIn(0, 100)
        v.findViewById<TextView>(R.id.tvMemVal).text = "${Fmt.pct(cur.memoryUsedPercent)}　${Fmt.bytes(cur.memoryUsed)} / ${Fmt.bytes(cur.memoryTotal)}"

        val swapTotal = cur.swapMemoryTotal ?: 0L
        v.findViewById<ProgressBar>(R.id.pbSwap).progress = (cur.swapMemoryUsedPercent ?: 0.0).toInt().coerceIn(0, 100)
        v.findViewById<TextView>(R.id.tvSwapVal).text =
            if (swapTotal > 0) "${Fmt.pct(cur.swapMemoryUsedPercent)}　${Fmt.bytes(cur.swapMemoryUsed)} / ${Fmt.bytes(swapTotal)}" else "未启用"

        v.findViewById<TextView>(R.id.tvLoad).text =
            "%.2f / %.2f / %.2f".format(cur.load1 ?: 0.0, cur.load5 ?: 0.0, cur.load15 ?: 0.0)
        v.findViewById<TextView>(R.id.tvProcs).text = Fmt.num(cur.procs)

        val now = System.currentTimeMillis()
        val sent = cur.netBytesSent ?: 0L
        val recv = cur.netBytesRecv ?: 0L
        if (lastTs > 0 && now > lastTs) {
            val secs = (now - lastTs) / 1000.0
            val up = (sent - lastSent) / secs
            val down = (recv - lastRecv) / secs
            v.findViewById<TextView>(R.id.tvNet).text = "↑ ${Fmt.rate(up)}　↓ ${Fmt.rate(down)}"
        } else {
            v.findViewById<TextView>(R.id.tvNet).text = "↑ ${Fmt.bytes(sent)}　↓ ${Fmt.bytes(recv)}"
        }
        lastSent = sent
        lastRecv = recv
        lastTs = now

        v.findViewById<TextView>(R.id.tvIo).text = "读 ${Fmt.bytes(cur.ioReadBytes)}　写 ${Fmt.bytes(cur.ioWriteBytes)}"
        v.findViewById<TextView>(R.id.tvCounts).text =
            "网站 ${Fmt.num(base.websiteNumber)}　数据库 ${Fmt.num(base.databaseNumber)}　应用 ${Fmt.num(base.appInstalledNumber)}"

        val box = v.findViewById<LinearLayout>(R.id.llDisk)
        box.removeAllViews()
        val disks = cur.diskData
        if (disks.isNullOrEmpty()) {
            val empty = TextView(requireContext())
            empty.text = "暂无磁盘数据"
            box.addView(empty)
        } else {
            val inflater = LayoutInflater.from(requireContext())
            disks.forEach { d ->
                val row = inflater.inflate(R.layout.item_disk, box, false)
                row.findViewById<TextView>(R.id.tvDiskPath).text = d.path ?: "-"
                row.findViewById<TextView>(R.id.tvDiskVal).text =
                    "${Fmt.pct(d.usedPercent)}　${Fmt.bytes(d.used)} / ${Fmt.bytes(d.total)}"
                row.findViewById<ProgressBar>(R.id.pbDisk).progress =
                    (d.usedPercent ?: 0.0).toInt().coerceIn(0, 100)
                box.addView(row)
            }
        }
    }

    companion object {
        private const val REFRESH_MS = 5000L
    }
}
