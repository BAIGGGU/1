package com.yuanbao.panel

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.appbar.MaterialToolbar

class MainActivity : AppCompatActivity() {

    lateinit var client: PanelClient
        private set

    private var tabId = R.id.nav_overview

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = Prefs.load(this)
        if (cfg.baseUrl.isBlank()) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }
        client = PanelClient(cfg)
        setContentView(R.layout.activity_main)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)

        val nav = findViewById<BottomNavigationView>(R.id.bottomNav)
        nav.setOnItemSelectedListener {
            tabId = it.itemId
            switchTab(it.itemId)
            true
        }
        nav.setOnItemReselectedListener {
            (currentFragment() as? Refreshable)?.refresh()
        }
        switchTab(tabId)
    }

    private fun switchTab(itemId: Int) {
        val frag: Fragment = when (itemId) {
            R.id.nav_containers -> ContainersFragment()
            R.id.nav_websites -> WebsitesFragment()
            else -> OverviewFragment()
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentHost, frag)
            .commit()
    }

    private fun currentFragment(): Fragment? =
        supportFragmentManager.findFragmentById(R.id.fragmentHost)

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_refresh -> {
                (currentFragment() as? Refreshable)?.refresh()
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, LoginActivity::class.java))
                true
            }
            R.id.action_about -> {
                showAbout()
                true
            }
            R.id.action_clear -> {
                MaterialAlertDialogBuilder(this)
                    .setTitle("清除连接配置")
                    .setMessage("将删除本机保存的地址与密钥，需要重新连接。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("清除") { _, _ ->
                        Prefs.clear(this)
                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                    }
                    .show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showAbout() {
        val cfg = client.config()
        val msg = """
            面板地址：${cfg.baseUrl}
            接口前缀：/api/${cfg.apiVersion}
            鉴权方式：${if (cfg.authMode == AuthMode.JWT) "账号密码 JWT" else "API Key 签名"}
            签名算法：${if (cfg.signMode == SignMode.MD5) "MD5（旧版）" else "HMAC-SHA256"}
            
            已对接接口：
            · dashboard/base、dashboard/current
            · containers/search、containers/operate
            · websites/search
            
            完整接口列表见：${client.swaggerUrl()}
        """.trimIndent()
        MaterialAlertDialogBuilder(this)
            .setTitle("关于与接口说明")
            .setMessage(msg)
            .setPositiveButton("关闭", null)
            .show()
    }
}

interface Refreshable {
    fun refresh()
}
