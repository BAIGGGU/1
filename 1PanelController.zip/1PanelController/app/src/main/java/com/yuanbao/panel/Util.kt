package com.yuanbao.panel

object Fmt {
    fun bytes(v: Long?): String {
        val b = (v ?: 0L).toDouble()
        if (b <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB", "PB")
        var i = 0
        var value = b
        while (value >= 1024 && i < units.size - 1) {
            value /= 1024
            i++
        }
        return if (i == 0) "${b.toLong()} B" else String.format("%.1f %s", value, units[i])
    }

    fun rate(bytesPerSec: Double): String {
        val v = if (bytesPerSec.isNaN() || bytesPerSec < 0) 0.0 else bytesPerSec
        val units = arrayOf("B/s", "KB/s", "MB/s", "GB/s")
        var i = 0
        var value = v
        while (value >= 1024 && i < units.size - 1) {
            value /= 1024
            i++
        }
        return String.format("%.1f %s", value, units[i])
    }

    fun pct(v: Double?): String = String.format("%.1f%%", v ?: 0.0)

    fun num(v: Number?): String = v?.toString() ?: "-"
}
