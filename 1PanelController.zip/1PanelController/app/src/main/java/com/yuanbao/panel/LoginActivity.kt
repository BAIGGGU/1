package com.yuanbao.panel

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {

    private lateinit var etUrl: TextInputEditText
    private lateinit var etEntrance: TextInputEditText
    private lateinit var etApiKey: TextInputEditText
    private lateinit var etUser: TextInputEditText
    private lateinit var etPass: TextInputEditText
    private lateinit var spAuth: Spinner
    private lateinit var spSign: Spinner
    private lateinit var spVersion: Spinner
    private lateinit var cbTrust: CheckBox
    private lateinit var groupKey: LinearLayout
    private lateinit var groupUser: LinearLayout
    private lateinit var btnSave: MaterialButton
    private lateinit var btnClear: MaterialButton
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        title = "连接 1Panel"

        etUrl = findViewById(R.id.etUrl)
        etEntrance = findViewById(R.id.etEntrance)
        etApiKey = findViewById(R.id.etApiKey)
        etUser = findViewById(R.id.etUser)
        etPass = findViewById(R.id.etPass)
        spAuth = findViewById(R.id.spAuth)
        spSign = findViewById(R.id.spSign)
        spVersion = findViewById(R.id.spVersion)
        cbTrust = findViewById(R.id.cbTrust)
        groupKey = findViewById(R.id.groupKey)
        groupUser = findViewById(R.id.groupUser)
        btnSave = findViewById(R.id.btnSave)
        btnClear = findViewById(R.id.btnClear)
        tvStatus = findViewById(R.id.tvStatus)

        setupSpinners()

        val saved = Prefs.load(this)
        if (saved.baseUrl.isNotBlank()) {
            etUrl.setText(saved.baseUrl)
            etEntrance.setText(saved.entranceCode)
            etApiKey.setText(saved.apiKey)
            etUser.setText(saved.username)
            etPass.setText(saved.password)
            cbTrust.isChecked = saved.trustAll
            spAuth.setSelection(if (saved.authMode == AuthMode.JWT) 1 else 0)
            spSign.setSelection(if (saved.signMode == SignMode.MD5) 1 else 0)
            spVersion.setSelection(if (saved.apiVersion == ApiVer.V1) 1 else 0)
            btnClear.visibility = View.VISIBLE
        }
        syncMode(if (saved.authMode == AuthMode.JWT) 1 else 0)

        spAuth.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>, v: View?, pos: Int, id: Long) = syncMode(pos)
            override fun onNothingSelected(p: AdapterView<*>) {}
        }

        btnSave.setOnClickListener { save() }
        btnClear.setOnClickListener {
            Prefs.clear(this)
            Snackbar.make(btnClear, "已清除连接配置", Snackbar.LENGTH_SHORT).show()
            recreate()
        }
        findViewById<TextView>(R.id.tvHelp).setOnClickListener { showHelp() }
    }

    private fun setupSpinners() {
        spAuth.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("API Key（推荐）", "账号密码（JWT）"))
        spSign.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("HMAC-SHA256（推荐）", "MD5（旧版兼容）"))
        spVersion.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("v2（/api/v2）", "v1（/api/v1）"))
    }

    private fun syncMode(pos: Int) {
        if (pos == 1) {
            groupKey.visibility = View.GONE
            groupUser.visibility = View.VISIBLE
        } else {
            groupKey.visibility = View.VISIBLE
            groupUser.visibility = View.GONE
        }
    }

    private fun buildConfig(): PanelConfig {
        var url = etUrl.text?.toString()?.trim().orEmpty()
        if (url.isBlank()) throw IllegalArgumentException("请填写面板地址")
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
        val cfg = PanelConfig(
            baseUrl = url,
            apiVersion = if (spVersion.selectedItemPosition == 1) ApiVer.V1 else ApiVer.V2,
            authMode = if (spAuth.selectedItemPosition == 1) AuthMode.JWT else AuthMode.API_KEY,
            signMode = if (spSign.selectedItemPosition == 1) SignMode.MD5 else SignMode.HMAC,
            apiKey = etApiKey.text?.toString()?.trim().orEmpty(),
            username = etUser.text?.toString()?.trim().orEmpty(),
            password = etPass.text?.toString()?.trim().orEmpty(),
            entranceCode = etEntrance.text?.toString()?.trim().orEmpty(),
            trustAll = cbTrust.isChecked,
            autoRefresh = Prefs.load(this).autoRefresh
        )
        if (cfg.authMode == AuthMode.API_KEY && cfg.apiKey.isBlank()) {
            throw IllegalArgumentException("请填写 API Key")
        }
        if (cfg.authMode == AuthMode.JWT && (cfg.username.isBlank() || cfg.password.isBlank())) {
            throw IllegalArgumentException("请填写面板用户名和密码")
        }
        return cfg
    }

    private fun save() {
        val cfg: PanelConfig = try {
            buildConfig()
        } catch (e: IllegalArgumentException) {
            tvStatus.text = e.message
            return
        }
        setLoading(true)
        tvStatus.text = "正在连接…"
        lifecycleScope.launch {
            val result: Pair<Boolean, String> = withContext(Dispatchers.IO) {
                try {
                    val client = PanelClient(cfg)
                    if (cfg.authMode == AuthMode.JWT) client.login()
                    val info = client.testConnection()
                    Pair(true, info)
                } catch (e: Exception) {
                    Pair(false, e.message ?: "连接失败")
                }
            }
            setLoading(false)
            if (result.first) {
                Prefs.save(this@LoginActivity, cfg)
                tvStatus.text = "连接成功：${result.second}"
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                finish()
            } else {
                tvStatus.text = "连接失败：${result.second}"
                Snackbar.make(btnSave, result.second, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        btnSave.isEnabled = !loading
        btnSave.text = if (loading) "连接中…" else "保存并连接"
    }

    private fun showHelp() {
        val msg = """
            1. 面板开启 API：v2.2.1 之前在「面板设置」，之后点左下角用户菜单 → API 接口，启用并创建 API Key。
            2. IP 白名单：填入手机出口 IP，或 0.0.0.0/0 允许全部（仅建议在可信内网）。
            3. 地址填写示例：https://192.168.1.10:10086（默认自签证书，可勾选信任）。
            4. 设置了安全入口时，填入口名（非完整 URL），App 会自动做 Base64 编码。
            5. 接口文档：面板地址 + /1panel/swagger/index.html
        """.trimIndent()
        android.app.AlertDialog.Builder(this)
            .setTitle("如何获取 API Key")
            .setMessage(msg)
            .setPositiveButton("知道了", null)
            .show()
    }
}
