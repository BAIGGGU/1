package com.yuanbao.panel

import com.google.gson.annotations.SerializedName

data class DiskInfo(
    @SerializedName("path") val path: String? = null,
    @SerializedName("type") val type: String? = null,
    @SerializedName("device") val device: String? = null,
    @SerializedName("total") val total: Long? = null,
    @SerializedName("used") val used: Long? = null,
    @SerializedName("free") val free: Long? = null,
    @SerializedName("usedPercent") val usedPercent: Double? = null
)

data class CurrentInfo(
    @SerializedName("uptime") val uptime: Long? = null,
    @SerializedName("timeSinceUptime") val timeSinceUptime: String? = null,
    @SerializedName("procs") val procs: Long? = null,
    @SerializedName("load1") val load1: Double? = null,
    @SerializedName("load5") val load5: Double? = null,
    @SerializedName("load15") val load15: Double? = null,
    @SerializedName("cpuUsedPercent") val cpuUsedPercent: Double? = null,
    @SerializedName("cpuTotal") val cpuTotal: Int? = null,
    @SerializedName("memoryTotal") val memoryTotal: Long? = null,
    @SerializedName("memoryUsed") val memoryUsed: Long? = null,
    @SerializedName("memoryAvailable") val memoryAvailable: Long? = null,
    @SerializedName("memoryUsedPercent") val memoryUsedPercent: Double? = null,
    @SerializedName("swapMemoryTotal") val swapMemoryTotal: Long? = null,
    @SerializedName("swapMemoryUsed") val swapMemoryUsed: Long? = null,
    @SerializedName("swapMemoryUsedPercent") val swapMemoryUsedPercent: Double? = null,
    @SerializedName("netBytesSent") val netBytesSent: Long? = null,
    @SerializedName("netBytesRecv") val netBytesRecv: Long? = null,
    @SerializedName("ioReadBytes") val ioReadBytes: Long? = null,
    @SerializedName("ioWriteBytes") val ioWriteBytes: Long? = null,
    @SerializedName("diskData") val diskData: List<DiskInfo>? = null
)

data class DashboardBase(
    @SerializedName("hostname") val hostname: String? = null,
    @SerializedName("os") val os: String? = null,
    @SerializedName("platform") val platform: String? = null,
    @SerializedName("platformVersion") val platformVersion: String? = null,
    @SerializedName("prettyDistro") val prettyDistro: String? = null,
    @SerializedName("kernelArch") val kernelArch: String? = null,
    @SerializedName("kernelVersion") val kernelVersion: String? = null,
    @SerializedName("ipV4Addr") val ipV4Addr: String? = null,
    @SerializedName("cpuCores") val cpuCores: Int? = null,
    @SerializedName("cpuLogicalCores") val cpuLogicalCores: Int? = null,
    @SerializedName("cpuModelName") val cpuModelName: String? = null,
    @SerializedName("websiteNumber") val websiteNumber: Int? = null,
    @SerializedName("databaseNumber") val databaseNumber: Int? = null,
    @SerializedName("appInstalledNumber") val appInstalledNumber: Int? = null,
    @SerializedName("currentInfo") val currentInfo: CurrentInfo? = null
)

data class ContainerInfo(
    @SerializedName("name") val name: String? = null,
    @SerializedName("containerID") val containerID: String? = null,
    @SerializedName("image") val image: String? = null,
    @SerializedName("state") val state: String? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("createTime") val createTime: String? = null,
    @SerializedName("cpuUsage") val cpuUsage: Double? = null,
    @SerializedName("memUsage") val memUsage: Long? = null
)

data class WebsiteInfo(
    @SerializedName("id") val id: Long? = null,
    @SerializedName("primaryDomain") val primaryDomain: String? = null,
    @SerializedName("alias") val alias: String? = null,
    @SerializedName("type") val type: String? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("remark") val remark: String? = null,
    @SerializedName("protocol") val protocol: String? = null
)
